
public class DatosCiudades {
	public String nombre="";
	public String comarca="";
	public int habitantes;
	public int metro2;
	
	public DatosCiudades(String nombre, String comarca, int habitantes, int metro2) {
		this.nombre=nombre;
		this.comarca=comarca;
		this.habitantes=habitantes;
		this.metro2=metro2;
	}
	public DatosCiudades() {
	}
}